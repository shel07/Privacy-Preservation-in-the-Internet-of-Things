package com.theromus.sha;

import static com.theromus.sha.Parameters.SHA3_224;
import static com.theromus.utils.HexUtils.getHex;

public class KeccakExamples {

    public static void main(String[] args) {
        int a = 9;
        String s = Integer.toString(a);
        s = getHex(s.getBytes());

        Keccak keccak = new Keccak();

        
     //   System.out.println("keccak-224 = " + keccak.getHash(s, KECCAK_224));
       // System.out.println("keccak-256 = " + keccak.getHash(s, KECCAK_256));
        //System.out.println("keccak-384 = " + keccak.getHash(s, KECCAK_384));
       // System.out.println("keccak-512 = " + keccak.getHash(s, KECCAK_512));

        
        
        long stTime = System.currentTimeMillis();
        System.out.println("sha3-224 = " + keccak.getHash(s, SHA3_224));
        long endTime = System.currentTimeMillis();       
        long NetTime = endTime - stTime;
        System.out.println("Hash Time (ms) to Access Data ==> \t" + (endTime - stTime));
        
        
       // System.out.println("sha3-256 = " + keccak.getHash(s, SHA3_256));
       // System.out.println("sha3-384 = " + keccak.getHash(s, SHA3_384));
       // System.out.println("sha3-512 = " + keccak.getHash(s, SHA3_512));

       // System.out.println("shake128 = " + keccak.getHash(s, SHAKE128));
       // System.out.println("shake256 = " + keccak.getHash(s, SHAKE256));
    }

}
