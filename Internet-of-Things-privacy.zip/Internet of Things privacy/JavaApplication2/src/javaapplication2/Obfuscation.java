/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author CSPhD-26
 */
import static com.sun.org.apache.xalan.internal.lib.ExsltMath.power;


//import java.math.*;
//import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

public class Obfuscation {

    public static void main(String[] str) {
        int PT[] = new int[3];
        int ST[] = new int[3];
        int RT[] = new int[3];
        int MT[] = new int[3];
        char CT[] = new char[3];

        //int c=0;
        //FETCHING DATA FROM DATABASE 
        Connection conn = null;

        try {
            // db parameters
            String url = "jdbc:sqlite:C:/sqlite/PlainText.db";
            // create a connection to the database
            conn = DriverManager.getConnection(url);

            System.out.println("Connection to SQLite has been established.");

            Statement stmt = conn.createStatement();

            //String t = "SELECT * FROM dhtreadings";
            String sql = "SELECT * FROM PlainText";
            ResultSet rs = stmt.executeQuery(sql);
            // ResultSet rs = stmt.executeQuery(query);

            // loop through the result set
            //while (rs.next()) {
            //  i++;
            //c++;
            for (int i = 0; i < 128; i++) {
                //System.out.println(rs.getInt("temperature"));
                rs.next();

                //if(i>1001)
                // {
                //System.out.println("--------------------------------------------------------------------------");
                System.out.println("Addend1:\t" + rs.getInt("addend1") + "\tAddent2:\t"
                        + rs.getInt("addend2") + "\tAddend3:\t"
                        + rs.getInt("addend3"));

                //System.out.println("Count is :"+ c);
                // }
                // START TIME COMPUTATION
                long stTime = System.currentTimeMillis();

                PT[0] = rs.getInt("addend1");
                PT[1] = rs.getInt("addend2");
                PT[2] = rs.getInt("addend3");

                ST[0] = (int) power(PT[0], 5);
                ST[1] = (int) power(PT[1], 5);
                ST[2] = (int) power(PT[2], 5);

                System.out.println("ST[0]:\t" + ST[0] + "\t ST[1]:\t" + ST[1]
                        + "\t ST[2]:\t" + ST[2]);

                Random n = new Random();
                int Rand1 = n.nextInt(4) + 1; // for rotation of ST[0] by Rand1

                Random n1 = new Random();
                int Rand2 = n1.nextInt(4) + 1; // for rotation of ST[0] by Rand1

                Random n2 = new Random();
                int Rand3 = n2.nextInt(4) + 1; // for rotation of ST[0] by Rand1

                System.out.println("Three Keys are: \t" + Rand1 + "\t" + Rand2 + "\t" + Rand3);

                // BEGIN INSERTING Keys INTO DATABASE 
                //DATABASE CONNECTION1 BEGIN
                Connection conn1 = null;

                try {
                    // db parameters
                    // String url1 = "jdbc:sqlite:C:/sqlite/gui/SQLiteStudio/ss1.db";
                    String url1 = "jdbc:sqlite:C:/sqlite/Keys.db";
                    // create a connection to the database
                    conn1 = DriverManager.getConnection(url1);

                    System.out.println("Connection1 to SQLite has been established.");

                    Statement stmt1 = conn1.createStatement();
                    String sql4;
                    // String sql = "INSERT INTO warehouses VALUES(?,?,?)";
                    //String sql = ("INSERT INTO warehouses(addend1,addend2,addend3) VALUES(?,?,?)",(em1,em2,em3));

                    sql4 = "INSERT INTO ThreeRandomKeys(key1,key2,key3) VALUES('" + Rand1 + "','" + Rand2 + "','" + Rand3 + "')";

                    //String sql = ("INSERT INTO warehouses (addend1,addend2,addend3) VALUES (?, ?, ?, ?)",(em1,em2,em3));
                    // String sql = "insert into" + warehouses + "em1,em2,em3";
                    // String sql = "INSERT INTO stuffToPlot (unix, datestamp, keyword, value) VALUES (?, ?, ?, ?)";
                    stmt1.executeQuery(sql4);
                    System.out.println("Keys are inserted successfully");

//stmt1.update();
                    // String t1 = "SELECT * FROM warehouses";
                    // ResultSet rs1    = stmt1.executeQuery(sql);
                    // ResultSet rs = stmt1.executeQuery(query);
                    // loop through the result set
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                } finally {
                    try {
                        if (conn1 != null) {
                            conn1.close();
                        }
                    } catch (SQLException ex) {
                        System.out.println(ex.getMessage());
                    }
                }

                //DATABASE CONNECTION 1 END
                // END INSERTING ENCRYPTED Keys DATABASE 
                // ROTATION START
                String FinalRorate1 = rotate(ST[0], Rand1);
                String FinalRorate2 = rotate(ST[1], Rand2);
                String FinalRorate3 = rotate(ST[2], Rand3);
                //RT[0]=Integer.toString(FinalRorate1);
                //RT[0]= Integer.toString((int) FinalRorate1);
                System.out.println("Final value after rotation: " + FinalRorate1 + "\t" + FinalRorate2 + "\t" + FinalRorate3);

                RT[0] = Integer.parseInt(FinalRorate1);
                RT[1] = Integer.parseInt(FinalRorate2);
                RT[2] = Integer.parseInt(FinalRorate3);

                //ROTATION END
                //for(int j=0;j<18;j++)
                // System.out.println("Final value after rotati");
                MT[0] = RT[0] % 256;
                MT[1] = RT[1] % 256;
                MT[2] = RT[2] % 256;
                System.out.println("\nModulo Division 1: " + MT[0] + "\n");
                System.out.println("\nModulo Division 2: " + MT[1] + "\n");
                System.out.println("\nModulo Division 3: " + MT[2] + "\n");

                CT[0] = (char) (MT[0]+32);
                CT[1] = (char) (MT[1]+32);
                CT[2] = (char) (MT[2]+32);
                
            System.out.println("\nModulo Division 1: " + CT[0]+"\n");
            System.out.println("\nModulo Division 2: " + CT[1]+"\n");
            System.out.println("\nModulo Division 3: " + CT[2]+"\n");
                
                
            
            
             // BEGIN INSERTING Keys INTO DATABASE 
                //DATABASE CONNECTION11 BEGIN
                Connection conn11 = null;

                try {
                    // db parameters
                    // String url1 = "jdbc:sqlite:C:/sqlite/gui/SQLiteStudio/ss1.db";
                    String url1 = "jdbc:sqlite:C:/sqlite/ObfuscatedData.db";
                    // create a connection to the database
                    conn11 = DriverManager.getConnection(url1);

                    System.out.println("Connection1 to SQLite has been established.");

                    Statement stmt11 = conn11.createStatement();
                    String sql5;
                    // String sql = "INSERT INTO warehouses VALUES(?,?,?)";
                    //String sql = ("INSERT INTO warehouses(addend1,addend2,addend3) VALUES(?,?,?)",(em1,em2,em3));

                    sql5 = "INSERT INTO Obfuscation(Oaddend1,Oaddend2,Oaddend3) VALUES('" + CT[0] + "','" + CT[1] + "','" + CT[2] + "')";

                    //String sql = ("INSERT INTO warehouses (addend1,addend2,addend3) VALUES (?, ?, ?, ?)",(em1,em2,em3));
                    // String sql = "insert into" + warehouses + "em1,em2,em3";
                    // String sql = "INSERT INTO stuffToPlot (unix, datestamp, keyword, value) VALUES (?, ?, ?, ?)";
                    stmt11.executeQuery(sql5);
                    System.out.println("Obfuscated data are inserted successfully");

//stmt1.update();
                    // String t1 = "SELECT * FROM warehouses";
                    // ResultSet rs1    = stmt1.executeQuery(sql);
                    // ResultSet rs = stmt1.executeQuery(query);
                    // loop through the result set
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                } finally {
                    try {
                        if (conn11 != null) {
                            conn11.close();
                        }
                    } catch (SQLException ex) {
                        System.out.println(ex.getMessage());
                    }
                }

                //DATABASE CONNECTION 1 END
                // END INSERTING ENCRYPTED Keys DATABASE 
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
                
                

                long endTime = System.currentTimeMillis();
                long NetTime = endTime - stTime;

                // System.out.println("\n Time(ms)\t"+ stTime);
                //System.out.println("\n Time(ms)\t"+ endTime);
                System.out.println("\n Time(ms)\t" + NetTime);

                //END TIIME COMPUTATIOIN
                // BEGIN INSERTING TIME COMPUTATION
                //DATABASE CONNECTION2 BEGIN
                Connection conn2 = null;

                try {
                    // db parameters
                    // String url1 = "jdbc:sqlite:C:/sqlite/gui/SQLiteStudio/ss1.db";
                    String url2 = "jdbc:sqlite:C:/sqlite/TimeComputation.db";
                    // create a connection to the database
                    conn2 = DriverManager.getConnection(url2);

                    System.out.println("Connection2 to SQLite has been established.");

                    Statement stmt2 = conn2.createStatement();
                    String sql2;
                    // String sql = "INSERT INTO warehouses VALUES(?,?,?)";
                    //String sql = ("INSERT INTO warehouses(addend1,addend2,addend3) VALUES(?,?,?)",(em1,em2,em3));
                    sql2 = "INSERT INTO SPTModel(time) VALUES('" + NetTime + "')";
                    //j = j+1;
                    //String sql = ("INSERT INTO warehouses (addend1,addend2,addend3) VALUES (?, ?, ?, ?)",(em1,em2,em3));
                    // String sql = "insert into" + warehouses + "em1,em2,em3";
                    // String sql = "INSERT INTO stuffToPlot (unix, datestamp, keyword, value) VALUES (?, ?, ?, ?)";

                    stmt2.executeQuery(sql2);
                    System.out.println("Time inserted successfully");

//stmt1.update();
                    // String t1 = "SELECT * FROM warehouses";
                    // ResultSet rs1    = stmt1.executeQuery(sql);
                    // ResultSet rs = stmt1.executeQuery(query);
                    // loop through the result set
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                } finally {
                    try {
                        if (conn2 != null) {
                            conn2.close();
                        }
                    } catch (SQLException ex) {
                        System.out.println(ex.getMessage());
                    }
                }

                //DATABASE CONNECTION 2 END
                // END INSERTING TIME COMPUTATION
                System.out.println("\n");

            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }

        //FETCHING DATA FROM DATABASE END
        //System.out.println("Count is :"+ c);
    }

// START function to rotate number
    private static String rotate(int N, int P) {
        String inpstring = "";
        long num;
        long z = 0;

        long number = N;
        long number1 = number;

        number = N;
        num = P;

        long start = number;

        int numdigits = (int) Math.log10((double) number); // would return numdigits - 1

        int multiplier = (int) Math.pow(10.0, (double) numdigits);

        //System.out.println(numdigits);
        //System.out.println(multiplier);
        //while(true)
        for (int i = 0; i < num; i++) {

            long q = number / 10;

            long r = number % 10;

            //1234 = 123;
            number = number / 10;

            number = number + multiplier * r;

            //System.out.println(number);
            z = (int) number;

            if (number == start) {
                break;
            }

        }

        int count = 0;

        while (number1 != 0) {
            // num = num/10 number
            number1 /= 10;
            ++count;
        }

        //System.out.println("Number of digits: " + count);     
        int count1 = 0;

        while (number != 0) {
            // num = num/10 number
            number /= 10;
            ++count1;
        }

        //  System.out.println("Number of digits: " + count1);     
        int Netcount = count - count1;
        //System.out.println("Netcouont: " + Netcount);     
        int a = 0;
        int p = 0;
        long l1, l2;
        l1 = 0;
        l2 = z;

        String s1 = Long.toString(l1);    // converting long to String
        String s2 = Long.toString(z);

        for (int i = 0; i < Netcount; i++) {
            //number = Integer.valueOf(String.valueOf(p) + String.valueOf(number));
            //a = Integer.parseInt(Integer.toString(p) + Integer.toString((int) number));

            //System.out.println("Number of digits: " + l1);     
            //System.out.println("Number z: " + z);     
            s2 = s1 + s2;
            // long l3=Long.valueOf(s3).longValue();    // converting String to long
            //z=l3;
            //System.out.println(s3);

        }

        // System.out.println("Final value after rotation: " + s2);      
        // return s2;         
        return s2;

    }

// END function to rotate number
}
