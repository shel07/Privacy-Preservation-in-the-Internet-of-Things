/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

/**
 *
 * @author CSPhD-26
 */
public class NewClass1 {
    
    public static void main(String[] str) {
  //DATABASE CONNECTION1 BEGIN
  Connection conn1 = null;
        
        try {
            // db parameters
           // String url1 = "jdbc:sqlite:C:/sqlite/gui/SQLiteStudio/ss1.db";
            String url1 = "jdbc:sqlite:C:/sqlite/sensordata.db";
            // create a connection to the database
            conn1 = DriverManager.getConnection(url1);
            
            System.out.println("Connection1 to SQLite has been established.");
            
            Statement stmt1  = conn1.createStatement();
            String sql = "INSERT INTO aa1(s1,s2,s3) VALUES(10,20,30)";
            //stmt1.update();
            String t1 = "SELECT * FROM datasize";
            ResultSet rs1    = stmt1.executeQuery(sql);
            // ResultSet rs = stmt1.executeQuery(query);
            
            // loop through the result set
} catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn1 != null) {
                    conn1.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
 
 //DATABASE CONNECTION 1 END
  
 
 
 
    
        
    
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
    
    } 
    
    
}
