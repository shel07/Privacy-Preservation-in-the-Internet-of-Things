/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Random;

/**
 *
 * @author CSPhD-26
 */
public class rr {
    
    public static void main(String[] str) {
    int max=10;
    int min=-10;
    
    int i=0;
    
    // creating a range of numbers between -10 and +10
    
    
    Random r = new Random();
             
               
                
    
    
    
    
    while(i<10)
    
    {
        int V = r.nextInt(max + 1 -min) + min; 
    System.out.println("No. is \t" + V);
    i++;
    
    }
    }
}
