/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.math.BigInteger;
import java.util.Random;
import java.util.stream.IntStream;
public class SKJ 
{
    public int P;
    
    
   public static void main(String[] str) 
    {

        int Addend[]=new int[3]; 
        int N = 20;
        int Sum = 0;
        
        for(int i=0;i<2;i++)
        {     
           
           Random n = new Random();

            int  Rand = n.nextInt(20) + 1;
            
            
            
          // System.out.println(Rand);  
          //int Rand;
                            
          if(Rand<(N-Sum))
            {
              Addend[i] = Rand;
              Sum = Sum+Rand;
            }            
          else 
              i = i-1;  
        }
        
    Addend[2] = N-Sum;        
   
    //System.out.println(N);
    
       for(int i=0;i<Addend.length;i++)
               {                     
                   System.out.println(Addend[i]);   
               }               
    }    
}
