/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author CSPhD-26
 */
public class CreateUser {
    
     public static void main(String[] arg) {
         
          
         
          Scanner scanner = new Scanner(System.in);
    System.out.print("What is your Name");
    String Name = scanner.next();
    System.out.print("Enter Your Password");
    String Password = scanner.next();
    
         int OTP   =(int)(Math.random()*9000)+1000;
         
        
         
         
         
         
         
         
         
                // BEGIN INSERTING Keys INTO DATABASE 
                //DATABASE CONNECTION1 BEGIN
                Connection conn14 = null;

                try {
                    // db parameters
                    // String url1 = "jdbc:sqlite:C:/sqlite/gui/SQLiteStudio/ss1.db";
                    String url14 = "jdbc:sqlite:C:/sqlite/User.db";
                    // create a connection to the database
                    conn14 = DriverManager.getConnection(url14);

                    System.out.println("Connection1 to SQLite has been established.");

                    Statement stmt1 = conn14.createStatement();
                    String sql14;
                    //String sql15;
                    // String sql = "INSERT INTO warehouses VALUES(?,?,?)";
                    //String sql = ("INSERT INTO warehouses(addend1,addend2,addend3) VALUES(?,?,?)",(em1,em2,em3));

                    sql14 = "INSERT INTO UserRegistration(Name,Password,OTP) VALUES('" + Name + "','" + Password+ "','" + OTP + "')";
                    //sql15 = "INSERT INTO ThreeRandomKeys(Mul_Factor1,Mul_Factor2,Mul_Factor3) VALUES('" + Mul_Factor1 + "','" + Mul_Factor2 + "','" + Mul_Factor3 + "')";
                    //String sql = ("INSERT INTO warehouses (addend1,addend2,addend3) VALUES (?, ?, ?, ?)",(em1,em2,em3));
                    // String sql = "insert into" + warehouses + "em1,em2,em3";
                    // String sql = "INSERT INTO stuffToPlot (unix, datestamp, keyword, value) VALUES (?, ?, ?, ?)";
                    stmt1.executeQuery(sql14);
                    //stmt1.executeQuery(sql15);
                    System.out.println("Keys are inserted successfully");

//stmt1.update();
                    // String t1 = "SELECT * FROM warehouses";
                    // ResultSet rs1    = stmt1.executeQuery(sql);
                    // ResultSet rs = stmt1.executeQuery(query);
                    // loop through the result set
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                } finally {
                    try {
                        if (conn14 != null) {
                            conn14.close();
                        }
                    } catch (SQLException ex) {
                        System.out.println(ex.getMessage());
                    }
                }

                //DATABASE CONNECTION 1 END
                // END INSERTING ENCRYPTED Keys DATABASE 
         
         
         
                
                
                
         
                
                
         
         
     }
    
}
