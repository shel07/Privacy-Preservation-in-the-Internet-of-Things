/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author CSPhD-26
 */
public class NewClass3 {
    
    
    public static void main(String[] str) {

   int Array[]=new int[3]; 
    int j=1;
    
    
 //DATABASE CONNECTION BEGIN
  Connection conn = null;
        
        try {
            // db parameters
            String url = "jdbc:sqlite:C:/sqlite/sensordata.db";
            // create a connection to the database
            conn = DriverManager.getConnection(url);
            
            System.out.println("Connection to SQLite has been established.");
            
            Statement stmt  = conn.createStatement();
            String t = "SELECT * FROM dhtreadings";
            ResultSet rs    = stmt.executeQuery(t);
            // ResultSet rs = stmt.executeQuery(query);
            
            // loop through the result set
           
            while (rs.next()) {
                j++;
                
       //System.out.println(rs.getInt("temperature"));
        System.out.println("--------------------------------------------------------------------------");
       
       System.out.println("Temperature value is ==> " + rs.getInt("temperature"));
       System.out.println("Count ==> " + j);
    
            } }
    catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
    
    
    
    
                }
    
    
}
    }
