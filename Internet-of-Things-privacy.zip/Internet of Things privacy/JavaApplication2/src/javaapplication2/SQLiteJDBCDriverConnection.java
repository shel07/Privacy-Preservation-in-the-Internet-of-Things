/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;


	

import java.math.BigInteger;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
 
/**
 *
 * @author sqlitetutorial.net
 */
public class SQLiteJDBCDriverConnection {
     /**
     * Connect to a sample database
     */
    
    
   
    public static void SQLiteJDBCDriverConnection() {
        Connection conn = null;
        int m1;
        try {
            // db parameters
            String url = "jdbc:sqlite:C:/sqlite/sensordata.db";
            // create a connection to the database
            conn = DriverManager.getConnection(url);
            
            System.out.println("Connection to SQLite has been established.");
            
            Statement stmt  = conn.createStatement();
            String t = "SELECT * FROM dhtreadings";
            ResultSet rs    = stmt.executeQuery(t);
            // ResultSet rs = stmt.executeQuery(query);
            
            // loop through the result set
            m1=rs.getInt("id");
            while (rs.next()) {
                m1=rs.getInt("id");
       
                System.out.println(rs.getInt("id") + "\t" + 
                                   rs.getInt("temperature") + "\t" +
                                   rs.getInt("humidity")+ "\t" +
                                   rs.getString("currentdate")+"\t" +
                                   rs.getString("currentime")+"\t" +
                                   rs.getString("device"));
            }
            
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SQLiteJDBCDriverConnection();
        

        
        
    }
}