/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author CSPhD-26
 */
public class AppendZero {
    public static void main(String[] arg) {
        
         StringBuilder sb1 = new StringBuilder();
                   
                    for(int i=0;i<2;i++)
                    {
                    sb1.append(0);
                    }
                     sb1.append(345);
        System.out.println("Final value after rotation: " +sb1);
        
        
        
        
        
        
         String inpstring = "";
        long num;
        long z = 0;

        long number = 6100;
        long number1 = number;

        //number = N;
        num = 1;

        long start = number;

        int numdigits = (int) Math.log10((double) number); // would return numdigits - 1

        int multiplier = (int) Math.pow(10.0, (double) numdigits);

        //System.out.println(numdigits);
        //System.out.println(multiplier);
        //while(true)
        for (int i = 0; i < num; i++) {

            long q = number / 10;

            long r = number % 10;

            //1234 = 123;
            number = number / 10;

            number = number + multiplier * r;

            //System.out.println(number);
            z = (int) number;

            if (number == start) {
                break;
            }

        }

        int count = 0;

        while (number1 != 0) {
            // num = num/10 number
            number1 /= 10;
            ++count;
        }

        //System.out.println("Number of digits: " + count);     
        int count1 = 0;

        while (number != 0) {
            // num = num/10 number
            number /= 10;
            ++count1;
        }

        //  System.out.println("Number of digits: " + count1);     
        int Netcount = count - count1;
        //System.out.println("Netcouont: " + Netcount);     
        int a = 0;
        int p = 0;
        long l1, l2;
        l1 = 0;
        l2 = z;

        String s1 = Long.toString(l1);    // converting long to String
        String s2 = Long.toString(z);

        for (int i = 0; i < Netcount; i++) {
            //number = Integer.valueOf(String.valueOf(p) + String.valueOf(number));
            //a = Integer.parseInt(Integer.toString(p) + Integer.toString((int) number));

            //System.out.println("Number of digits: " + l1);     
            //System.out.println("Number z: " + z);     
            s2 = s1 + s2;
            // long l3=Long.valueOf(s3).longValue();    // converting String to long
            //z=l3;
            //System.out.println(s3);

        }

        
        
        System.out.println("result: " +s2);
        
        
        
        
        String str ="6100";
        
       // int len = str.length();
       int len=2;  // Note: it require one more position from original roation position
      
        // Generate all rotations one by one and print
        StringBuffer sb = null; 
         
        for (int i = 0; i < len; i++)
        {
            sb = new StringBuffer();
             
            int j = i;  // Current index in str
            int k = 0;  // Current index in temp
      
            // Copying the second part from the point
            // of rotation.
            for (int k2 = j; k2 < str.length(); k2++) {
                sb.insert(k, str.charAt(j));
                k++;
                j++;
            }
      
            // Copying the first part from the point
            // of rotation.
            j = 0;
            while (j < i)
            {
                sb.insert(k, str.charAt(j));
                j++;
                k++;
            }
      
            
        }
        
        
        System.out.println(sb);
        
        int b = Integer.parseInt(sb.toString());
        
        
         System.out.println("sssssssssssssssssss"+b);
        
        
    }
}
