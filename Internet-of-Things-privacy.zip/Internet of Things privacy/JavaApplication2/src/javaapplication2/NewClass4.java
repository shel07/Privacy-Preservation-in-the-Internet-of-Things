/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author CSPhD-26
 */
public class NewClass4 {
    
     public static void main(String[] arg) {
                String str3 = "123";
                //int rot = str3.length();
                int len = 4;
                if(len>str3.length()+1)
                {
                len =str3.length()+1;
                }
         //int len=3;  // Note: it require one more position from original roation position
      //System.out.println("Key22 is\t"+key22);
        // Generate all rotations one by one and print
         // StringBuilder sb = new StringBuilder();
 // sb = null;          
        StringBuffer sb = null; 
         
        for (int i = 0; i < len; i++)
        {
            sb = new StringBuffer();
             
            int j = i;  // Current index in str
            int k = 0;  // Current index in temp
      
            // Copying the second part from the point
            // of rotation.
            for (int k2 = j; k2 < str3.length(); k2++) {
                sb.insert(k, str3.charAt(j));
                k++;
                j++;
            }
      
            // Copying the first part from the point
            // of rotation.
            j = 0;
            while (j < i)
            {
                sb.insert(k, str3.charAt(j));
                j++;
                k++;
            }
      
            
        }
        
        
        //System.out.println(sb);
        
          
          //String str11 = 
        //string OST = Integer.parseInt(sb.toString()); // GOT FINAL ADDEND1 :) :)
         //System.out.println("FINAL LEFT ROTATED ADDEND 2 IS:\t"+OST[2]);
         
          try{
        //OST[2] = Integer.parseInt(sb.toString()); // GOT FINAL ADDEND1 :) :)
    }catch(NumberFormatException ex){ // handle your exception
      System.out.println(ex.getMessage());
    }

         
         
          System.out.println("\n"+sb);
      //sb3.setLength(0);
                 
                // key33=0;      
}
}