/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author CSPhD-26
 */


import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Obfuscation1 {
    
   /**
     * Connect to the test.db database
     * @return the Connection object
     */
    private Connection connect() {
        // SQLite connection string
        String url = "jdbc:sqlite:C:/sqlite/DataStore.db";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }
 
    
    /**
     * select all rows in the warehouses table
     */
    public void selectAll(){
        String sql = "SELECT addend1,addend2,addend3 FROM warehouses";
        
        try (Connection conn = this.connect();
             Statement stmt  = conn.createStatement();
             ResultSet rs    = stmt.executeQuery(sql)){
            
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("addend1") +  "\t" + 
                                   rs.getInt("addend2") + "\t" +
                                   rs.getInt("addend3"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        
        
    }
    
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Obfuscation app = new Obfuscation();
        app.selectAll();
    } 
    
    
    
}
