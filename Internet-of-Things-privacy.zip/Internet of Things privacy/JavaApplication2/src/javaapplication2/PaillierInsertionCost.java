

/**
 *
 * @author CSPhD-26
 Paillier23 {
    
}
*/



package javaapplication2;


import java.math.*;
//import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;


public class  PaillierInsertionCost {

    
          
    
/**
* p and q are two large primes.
* lambda = lcm(p-1, q-1) = (p-1)*(q-1)/gcd(p-1, q-1).
*/
private BigInteger p, q, lambda;
/**
* n = p*q, where p and q are two large primes.
*/
public BigInteger n;
/**
* nsquare = n*n
*/
public BigInteger nsquare;
/**
* a random integer in Z*_{n^2} where gcd (L(g^lambda mod n^2), n) = 1.
*/
private BigInteger g;
/**
* number of bits of modulus
*/
private int bitLength;

/**
* Constructs an instance of the Paillier cryptosystem.
* @param bitLengthVal number of bits of modulus
* @param certainty The probability that the new BigInteger represents a prime number will exceed (1 - 2^(-certainty)). The execution time of this constructor is proportional to the value of this parameter.
*/
public Paillier(int bitLengthVal, int certainty) {
KeyGeneration(bitLengthVal, certainty);
}

/**
* Constructs an instance of the Paillier cryptosystem with 512 bits of modulus and at least 1-2^(-64) certainty of primes generation.
*/
public Paillier() {
KeyGeneration(512, 64);
}









/**
* Sets up the public key and private key.
* @param bitLengthVal number of bits of modulus.
* @param certainty The probability that the new BigInteger represents a prime number will exceed (1 - 2^(-certainty)). The execution time of this constructor is proportional to the value of this parameter.
*/
public void KeyGeneration(int bitLengthVal, int certainty) {
bitLength = bitLengthVal;
/*Constructs two randomly generated positive BigIntegers that are probably prime, with the specified bitLength and certainty.*/
p = new BigInteger(bitLength / 2, certainty, new Random());
q = new BigInteger(bitLength / 2, certainty, new Random());

n = p.multiply(q);
nsquare = n.multiply(n);

g = new BigInteger("2");
lambda = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE)).divide(
p.subtract(BigInteger.ONE).gcd(q.subtract(BigInteger.ONE)));
/* check whether g is good.*/
if (g.modPow(lambda, nsquare).subtract(BigInteger.ONE).divide(n).gcd(n).intValue() != 1) {
System.out.println("g is not good. Choose g again.");
System.exit(1);
}
}

/**
* Encrypts plaintext m. ciphertext c = g^m * r^n mod n^2. This function explicitly requires random input r to help with encryption.
* @param m plaintext as a BigInteger
* @param r random plaintext to help with encryption
* @return ciphertext as a BigInteger
*/
public BigInteger Encryption(BigInteger m, BigInteger r) {
return g.modPow(m, nsquare).multiply(r.modPow(n, nsquare)).mod(nsquare);
}

/**
* Encrypts plaintext m. ciphertext c = g^m * r^n mod n^2. This function automatically generates random input r (to help with encryption).
* @param m plaintext as a BigInteger
* @return ciphertext as a BigInteger
*/
public BigInteger Encryption(BigInteger m) {
BigInteger r = new BigInteger(bitLength, new Random());
return g.modPow(m, nsquare).multiply(r.modPow(n, nsquare)).mod(nsquare);

}

/**
* Decrypts ciphertext c. plaintext m = L(c^lambda mod n^2) * u mod n, where u = (L(g^lambda mod n^2))^(-1) mod n.
* @param c ciphertext as a BigInteger
* @return plaintext as a BigInteger
*/
public BigInteger Decryption(BigInteger c) {
BigInteger u = g.modPow(lambda, nsquare).subtract(BigInteger.ONE).divide(n).modInverse(n);
return c.modPow(lambda, nsquare).subtract(BigInteger.ONE).divide(n).multiply(u).mod(n);
}








/**
* main function
* @param str intput string
*/
public static void main(String[] str) {

   int Array[]=new int[3]; 
    int j=1;
    
 //DATABASE CONNECTION BEGIN
  Connection conn = null;
        
        try {
            // db parameters
            String url = "jdbc:sqlite:C:/sqlite/sensordata.db";
            // create a connection to the database
            conn = DriverManager.getConnection(url);
            
            System.out.println("Connection to SQLite has been established.");
            
            Statement stmt  = conn.createStatement();
            String t = "SELECT * FROM dhtreadings";
            //ResultSet rs    = stmt.executeQuery(t);
            ResultSet rs    = stmt.executeQuery(t);
            
            // ResultSet rs = stmt.executeQuery(query);
            
            // loop through the result set
           
            while (rs.next()) {
                
       //System.out.println(rs.getInt("temperature"));
        System.out.println("--------------------------------------------------------------------------");
       
       System.out.println("Temperature value is ==> " + rs.getInt("temperature")+ "\t" + rs.getInt("id"));
                                   
               /*  System.out.println(rs.getInt("id") + "\t" + 
                                   rs.getInt("temperature") + "\t" +
                                   rs.getInt("humidity")+ "\t" +
                                   rs.getString("currentdate")+"\t" +
                                   rs.getString("currentime")+"\t" +
                                   rs.getString("device")); */
               
               
               
               
               
           /*    for(int i=0;i<Array.length;i++)
               {
                   
                   Array[i] = rs.getInt("temperature");
                   
               }
               
               
               for(int i=0;i<Array.length;i++)
               {
                       
                   System.out.println("Temperatute");   
                   System.out.println(Array[i]);   
               } */
               
               
               
               // Work Start
               
               
               int Addend[]=new int[3]; 
                int N = rs.getInt("temperature");
                int Sum = 0;
               
                for(int i=0;i<2;i++)
                {     
           
                      Random n = new Random();

                        int  Rand = n.nextInt(20) + 1;
            
            
            
          // System.out.println(Rand);  
          //int Rand;
                            
                     if(Rand<(N-Sum))
                         {
                          Addend[i] = Rand;
                          Sum = Sum+Rand;
                         }            
                      else 
                      i = i-1;  
                         }
        
                 Addend[2] = N-Sum;        
   
                     //System.out.println(N);
    
                 for(int i=0;i<Addend.length;i++)
                         {     
                             
                           //System.out.println(Addend[i]);   
                           System.out.println("Data Addend  ==> " +(i+1)+"\t is \t"+Addend[i]);
                          }               
               
     
            
               //Work End
               
               
               
               
              // TIME COMPUTATION START
long stTime = System.currentTimeMillis();

/* instantiating an object of Paillier cryptosystem*/

Paillier paillier = new Paillier();
/* instantiating two plaintext msgs*/
BigInteger m1 = BigInteger.valueOf(Addend[0]);
BigInteger m2 = BigInteger.valueOf(Addend[1]);
BigInteger m3 = BigInteger.valueOf(Addend[2]);
/*BigInteger m1 = new BigInteger(Addend[1]);
BigInteger m2 = new BigInteger("60");
BigInteger m3 = new BigInteger("60"); */




/* encryption*/

BigInteger em1 = paillier.Encryption(m1);
BigInteger em2 = paillier.Encryption(m2);
BigInteger em3 = paillier.Encryption(m3);
// BigInteger em2 = paillier.Encryption(m2);




System.out.printf("%n");
/* printout encrypted text*/
System.out.printf("%n Data Addend " + Addend[0] +"\t encryption\n");
System.out.println(em1);
System.out.printf("%n Data Addend  " + Addend[1] +"\t encryption\n");
System.out.println(em2);
System.out.printf("%n Data Addend  " + Addend[2] +"'\t encryption\n");
System.out.println(em3);
// System.out.println(em2);





System.out.printf("%n");
/* printout decrypted text */
System.out.printf("%n Data Addend " + Addend[0] +"\t decryption\n");
System.out.println(paillier.Decryption(em1).toString());
System.out.printf("%n Data Addend " + Addend[0] +"\t decryption\n");
System.out.println(paillier.Decryption(em2).toString());
System.out.printf("%n Data Addend " + Addend[0] +"\t decryption\n");
System.out.println(paillier.Decryption(em3).toString());
// System.out.println(paillier.Decryption(em2).toString());


System.out.printf("%n");







// BEGIN INSERTING Addend DATA INTO DATABASE FOR SIZE COMPUTATION
 
 
      //DATABASE CONNECTION1 BEGIN
  Connection conn4 = null;
        
        try {
            String url8 = "jdbc:sqlite:C:/sqlite/PlainText.db";
            // create a connection to the database
            conn4 = DriverManager.getConnection(url8);
            
            
            
            System.out.println("Connection1 to SQLite has been established.");
            
            Statement stmt2  = conn4.createStatement();
             String sql4;
   
            sql4 = "INSERT INTO PlainText(addend1,addend2,addend3) VALUES('"+m1+"','"+m2+"','"+m3+"')";
            
            
             
             stmt2.executeQuery(sql4);
             System.out.println("Encrypted data inserted successfully");
                
} catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn4 != null) {
                    conn4.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
 
 //DATABASE CONNECTION 4 END
 

 // END INSERTING Addend  INTO DATABASE FOR SIZE COMPUTATION





















long endTime = System.currentTimeMillis();
long NetTime = endTime - stTime;
// TIME COMPUTATIN END

System.out.println("Time (ms) ==> " + (endTime - stTime));


// SQLiteJDBCDriverConnection();
 
               
               
 System.out.println("------------------------------------------------------------------");      
               
               
 
 
 
 
 
 
 





 
 // BEGIN INSERTING ENCRYPTED DATA INTO DATABASE FOR SIZE COMPUTATION
 
 
      //DATABASE CONNECTION1 BEGIN
  Connection conn1 = null;
        
        try {
            // db parameters
           // String url1 = "jdbc:sqlite:C:/sqlite/gui/SQLiteStudio/ss1.db";
            String url1 = "jdbc:sqlite:C:/sqlite/DataStore.db";
            // create a connection to the database
            conn1 = DriverManager.getConnection(url1);
            
            
            
            System.out.println("Connection1 to SQLite has been established.");
            
            Statement stmt1  = conn1.createStatement();
             String sql;
            sql = "INSERT INTO warehouses(addend1,addend2,addend3) VALUES('"+em1+"','"+em2+"','"+em3+"')";
            
             
             System.out.println("Plaintext of addend inserted successfully");
             stmt1.executeQuery(sql);
                
} catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn1 != null) {
                    conn1.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
 
 //DATABASE CONNECTION 1 END
 

 // END INSERTING ENCRYPTED DATA INTO DATABASE FOR SIZE COMPUTATION



 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

 
 
 
 
 
 // BEGIN INSERTING TIME COMPUTATION
 
 //DATABASE CONNECTION2 BEGIN
  Connection conn2 = null;
        
        try {
            // db parameters
           // String url1 = "jdbc:sqlite:C:/sqlite/gui/SQLiteStudio/ss1.db";
            String url2 = "jdbc:sqlite:C:/sqlite/TimeComputation.db";
            // create a connection to the database
            conn1 = DriverManager.getConnection(url2);
            
            System.out.println("Connection2 to SQLite has been established.");
            
            Statement stmt2  = conn1.createStatement();
             String sql2;
           // String sql = "INSERT INTO warehouses VALUES(?,?,?)";
            //String sql = ("INSERT INTO warehouses(addend1,addend2,addend3) VALUES(?,?,?)",(em1,em2,em3));
            sql2 = "INSERT INTO ExistingModel(time) VALUES('"+NetTime+"')";
            j = j+1;
           //String sql = ("INSERT INTO warehouses (addend1,addend2,addend3) VALUES (?, ?, ?, ?)",(em1,em2,em3));
          // String sql = "insert into" + warehouses + "em1,em2,em3";
           // String sql = "INSERT INTO stuffToPlot (unix, datestamp, keyword, value) VALUES (?, ?, ?, ?)";
            
             stmt2.executeQuery(sql2);
             System.out.println("Time inserted successfully");
                
//stmt1.update();
           // String t1 = "SELECT * FROM warehouses";
           // ResultSet rs1    = stmt1.executeQuery(sql);
            // ResultSet rs = stmt1.executeQuery(query);
            
            // loop through the result set
} catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn2 != null) {
                    conn2.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
 
 //DATABASE CONNECTION 2 END
 
 
 // END INSERTING TIME COMPUTATION
 
 
 
 
 
 
              
               
            }
            
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
 
 //DATABASE CONNECTION END
    
    
    
 
 
 /*
 
 //DATABASE CONNECTION1 BEGIN
  Connection conn1 = null;
        
        try {
            // db parameters
            String url1 = "jdbc:sqlite:C:/sqlite/gui/SQLiteStudio/datasize.db";
            // create a connection to the database
            conn1 = DriverManager.getConnection(url1);
            
            System.out.println("Connection1 to SQLite has been established.");
            
            Statement stmt1  = conn1.createStatement();
            String t1 = "SELECT * FROM datasize";
            ResultSet rs1    = stmt1.executeQuery(t1);
            // ResultSet rs = stmt1.executeQuery(query);
            
            // loop through the result set
} catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn1 != null) {
                    conn1.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
 
 //DATABASE CONNECTION 1 END



 */
 
 

}




}

