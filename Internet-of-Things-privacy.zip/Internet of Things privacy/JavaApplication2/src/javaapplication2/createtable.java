/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author CSPhD-26
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
 
/**
 *
 * @author sqlitetutorial.net
 */
public class createtable {
 
    /**
     * Create a new table in the test database
     *
     */
    public static void createNewTable() {
        // SQLite connection string
        //String url = "jdbc:sqlite:C://TimeComputation.db";
        //String url = "jdbc:sqlite:C://sqlite//TimeComputation.db";
        
       String url = "jdbc:sqlite:D://CPW_PPM_Model//Programmig_for_PPM_Model//sqlite//GatewayDataManagement.db";
       
        
        
        
        
        String sql = "CREATE TABLE IF NOT EXISTS HashValuesforMyPPMModel (\n"
                + "	H1 integer PRIMARY KEY,\n"
                + "	H2 integer NOT NULL,\n"
                + "	H3 integer real\n"
                + ");";
        
        
        
        
        
        
        
        
        
        
        
        try (Connection conn = DriverManager.getConnection(url);
                Statement stmt = conn.createStatement()) {
            // create a new table
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        createNewTable();
    }
 
}