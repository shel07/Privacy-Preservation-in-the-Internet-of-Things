// PaillierDataAccessProtocolCost 


        

/**
 *
 * @author CSPhD-26
 Paillier23 {
    
}
*/

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;


import java.math.*;
//import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;


public class  PaillierDataAccessProtocolCost  {

    
          
    
/**
* p and q are two large primes.
* lambda = lcm(p-1, q-1) = (p-1)*(q-1)/gcd(p-1, q-1).
*/
private BigInteger p, q, lambda;
/**
* n = p*q, where p and q are two large primes.
*/
public BigInteger n;
/**
* nsquare = n*n
*/
public BigInteger nsquare;
/**
* a random integer in Z*_{n^2} where gcd (L(g^lambda mod n^2), n) = 1.
*/
private BigInteger g;
/**
* number of bits of modulus
*/
private int bitLength;

/**
* Constructs an instance of the Paillier cryptosystem.
* @param bitLengthVal number of bits of modulus
* @param certainty The probability that the new BigInteger represents a prime number will exceed (1 - 2^(-certainty)). The execution time of this constructor is proportional to the value of this parameter.
*/
public PaillierDataAccessProtocolCost(int bitLengthVal, int certainty) {
KeyGeneration(bitLengthVal, certainty);
}

/**
* Constructs an instance of the Paillier cryptosystem with 512 bits of modulus and at least 1-2^(-64) certainty of primes generation.
*/
public PaillierDataAccessProtocolCost() {
KeyGeneration(512, 64);
}









/**
* Sets up the public key and private key.
* @param bitLengthVal number of bits of modulus.
* @param certainty The probability that the new BigInteger represents a prime number will exceed (1 - 2^(-certainty)). The execution time of this constructor is proportional to the value of this parameter.
*/
public void KeyGeneration(int bitLengthVal, int certainty) {
bitLength = bitLengthVal;
/*Constructs two randomly generated positive BigIntegers that are probably prime, with the specified bitLength and certainty.*/
p = new BigInteger(bitLength / 2, certainty, new Random());
q = new BigInteger(bitLength / 2, certainty, new Random());

n = p.multiply(q);
nsquare = n.multiply(n);

g = new BigInteger("2");
lambda = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE)).divide(
p.subtract(BigInteger.ONE).gcd(q.subtract(BigInteger.ONE)));
/* check whether g is good.*/
if (g.modPow(lambda, nsquare).subtract(BigInteger.ONE).divide(n).gcd(n).intValue() != 1) {
System.out.println("g is not good. Choose g again.");
System.exit(1);
}
}

/**
* Encrypts plaintext m. ciphertext c = g^m * r^n mod n^2. This function explicitly requires random input r to help with encryption.
* @param m plaintext as a BigInteger
* @param r random plaintext to help with encryption
* @return ciphertext as a BigInteger
*/
public BigInteger Encryption(BigInteger m, BigInteger r) {
return g.modPow(m, nsquare).multiply(r.modPow(n, nsquare)).mod(nsquare);
}

/**
* Encrypts plaintext m. ciphertext c = g^m * r^n mod n^2. This function automatically generates random input r (to help with encryption).
* @param m plaintext as a BigInteger
* @return ciphertext as a BigInteger
*/
public BigInteger Encryption(BigInteger m) {
BigInteger r = new BigInteger(bitLength, new Random());
return g.modPow(m, nsquare).multiply(r.modPow(n, nsquare)).mod(nsquare);

}

/**
* Decrypts ciphertext c. plaintext m = L(c^lambda mod n^2) * u mod n, where u = (L(g^lambda mod n^2))^(-1) mod n.
* @param c ciphertext as a BigInteger
* @return plaintext as a BigInteger
*/
public BigInteger Decryption(BigInteger c) {
BigInteger u = g.modPow(lambda, nsquare).subtract(BigInteger.ONE).divide(n).modInverse(n);
return c.modPow(lambda, nsquare).subtract(BigInteger.ONE).divide(n).multiply(u).mod(n);
}








/**
* main function
* @param str intput string
*/
public static void main(String[] str) {

   int Array[]=new int[3]; 
   int Addend[]=new int[3]; 
    int j=1;
    //long TotalTimeEcryptionDecryption_Start = System.currentTimeMillis();
    
    long stTime = System.currentTimeMillis();
    
 //DATABASE CONNECTION BEGIN
  Connection conn = null;
        
        try {
            // db parameters
            String url = "jdbc:sqlite:D:/CPW_PPM_Model/Programmig_for_PPM_Model/sqlite/PlainText.db";
            // create a connection to the database
            conn = DriverManager.getConnection(url);
            
            System.out.println("Connection to SQLite has been established.");
            
            Statement stmt  = conn.createStatement();
            String t = "SELECT * FROM PlainText";
            //ResultSet rs    = stmt.executeQuery(t);
            ResultSet rs    = stmt.executeQuery(t);
            
            // ResultSet rs = stmt.executeQuery(query);
            
            // loop through the result set
         int count = 0;
            while (rs.next()) {
                
                
                 long TotalTimeEcryptionDecryption_Start = System.currentTimeMillis();
       //System.out.println(rs.getInt("temperature"));
        System.out.println("--------------------------------------------------------------------------");
       
     count = count + 1;

System.out.printf(" IT IS JUST DATA COUNTER \t" + count);
/* instantiating an object of Paillier cryptosystem*/

Addend[0]= rs.getInt("addend1");
Addend[1]=rs.getInt("addend2");
Addend[2]=rs.getInt("addend3");






PaillierDataAccessProtocolCost PaillierDataAccessProtocolCost = new PaillierDataAccessProtocolCost();
/* instantiating two plaintext msgs*/
BigInteger m1 = BigInteger.valueOf(Addend[0]);
BigInteger m2 = BigInteger.valueOf(Addend[1]);
BigInteger m3 = BigInteger.valueOf(Addend[2]);
/*BigInteger m1 = new BigInteger(Addend[1]);
BigInteger m2 = new BigInteger("60");
BigInteger m3 = new BigInteger("60"); */







System.out.printf("%n");
/* printout encrypted text*/
System.out.printf("%n Data Addend 1 \t" + Addend[0] +"\n");
System.out.println(m1);
System.out.printf("%n Data Addend 2\t" + Addend[1] +"\n");
System.out.println(m2);
System.out.printf("%n Data Addend 3 \t" + Addend[2] +"\n");
System.out.println(m3);
// System.out.println(em2);




































/* encryption*/

BigInteger em1 = PaillierDataAccessProtocolCost.Encryption(m1);
BigInteger em2 = PaillierDataAccessProtocolCost.Encryption(m2);
BigInteger em3 = PaillierDataAccessProtocolCost.Encryption(m3);
// BigInteger em2 = paillier.Encryption(m2);

System.out.printf("%n");
/* printout encrypted text*/
System.out.printf("%n Data Addend " + Addend[0] +"\t encryption\n");
System.out.println(em1);
System.out.printf("%n Data Addend  " + Addend[1] +"\t encryption\n");
System.out.println(em2);
System.out.printf("%n Data Addend  " + Addend[2] +"'\t encryption\n");
System.out.println(em3);
// System.out.println(em2);




/* test homomorphic properties -> D(E(m1)^m2 mod n^2) = (m1*m2*m3) mod n */
            BigInteger expo_em1em2 = em1.modPow(m2, PaillierDataAccessProtocolCost.nsquare);
            BigInteger expo_em1em2em3 = expo_em1em2.modPow(m3, PaillierDataAccessProtocolCost.nsquare);
            System.out.println("Encrypted product (Which will be send to the user): " + expo_em1em2em3);
            //BigInteger prod_m1m2m3 = m1.multiply(m2).multiply(m3).mod(PaillierDataAccessProtocolCost.n);
            //System.out.println("original product: " + prod_m1m2m3.toString());
           // System.out.println("decrypted product: " + PaillierDataAccessProtocolCost.Decryption(expo_em1em2em3).toString());
 



long endTime = System.currentTimeMillis();
long NetTime = endTime - stTime;
// TIME COMPUTATIN END

System.out.println("Pailler Data Ecryption Time (ms) to Access Data ==> \t" + (endTime - stTime));



//START User side Data Decrypion Cost 

long startTime1 = System.currentTimeMillis();

   BigInteger prod_m1m2m3 = m1.multiply(m2).multiply(m3).mod(PaillierDataAccessProtocolCost.n);
     System.out.println("original product: " + prod_m1m2m3.toString());
     System.out.println("decrypted product: " + PaillierDataAccessProtocolCost.Decryption(expo_em1em2em3).toString());
 
long endTime1 = System.currentTimeMillis();
 



 long NetTime1 = endTime1 - startTime1;
 
 System.out.println("Paillier Data Decryption Time (ms) to Access Data ==>\t " + NetTime1);
 // END User side Data Decrypion Cost
 
 long TotalTimeEcryptionDecryption_End = System.currentTimeMillis();
 
 
 long TotalTimeEcryptionDecryption = TotalTimeEcryptionDecryption_End-TotalTimeEcryptionDecryption_Start;
 
 System.out.println("Total Ecryption+Decryption Time (ms) to Access Data ==>\t " + TotalTimeEcryptionDecryption);
 
 
 
 
 

 
 // BEGIN INSERTING TIME COMPUTATION
 
 //DATABASE CONNECTION2 BEGIN
  Connection conn2 = null;
        
        try {
            // db parameters
           // String url1 = "jdbc:sqlite:C:/sqlite/gui/SQLiteStudio/ss1.db";
            String url2 = "jdbc:sqlite:D:/CPW_PPM_Model/Programmig_for_PPM_Model/sqlite/TimeComputation.db";
            // create a connection to the database
            conn2 = DriverManager.getConnection(url2);
            
            System.out.println("Connection2 to SQLite has been established.");
            
            Statement stmt2  = conn2.createStatement();
             String sql2;
           // String sql = "INSERT INTO warehouses VALUES(?,?,?)";
            //String sql = ("INSERT INTO warehouses(addend1,addend2,addend3) VALUES(?,?,?)",(em1,em2,em3));
            sql2 = "INSERT INTO Existing_DataAccess(time) VALUES('"+TotalTimeEcryptionDecryption+"')";
            j = j+1;
           //String sql = ("INSERT INTO warehouses (addend1,addend2,addend3) VALUES (?, ?, ?, ?)",(em1,em2,em3));
          // String sql = "insert into" + warehouses + "em1,em2,em3";
           // String sql = "INSERT INTO stuffToPlot (unix, datestamp, keyword, value) VALUES (?, ?, ?, ?)";
            
             stmt2.executeQuery(sql2);
             System.out.println("Time inserted successfully");
                
//stmt1.update();
           // String t1 = "SELECT * FROM warehouses";
           // ResultSet rs1    = stmt1.executeQuery(sql);
            // ResultSet rs = stmt1.executeQuery(query);
            
            // loop through the result set
} catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn2 != null) {
                    conn2.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
 
 //DATABASE CONNECTION 2 END
 
 
 // END INSERTING TIME COMPUTATION
 
 
 
 
 
     // NOTE:- I CAN INSERT DATA ENCRYPTION TIME NetTime by crating a new SQLITE TABLE HERE
 
 
 
          
 
 
 
 
         // BEGIN INSERTING TIME COMPUTATION for DECRYPTION AT USER SIDE
 
 //DATABASE CONNECTION 3 BEGIN
  Connection conn3 = null;
        
        try {
            // db parameters
           // String url1 = "jdbc:sqlite:C:/sqlite/gui/SQLiteStudio/ss1.db";
            String url3 = "jdbc:sqlite:D:/CPW_PPM_Model/Programmig_for_PPM_Model/sqlite/TimeComputation.db";
            // create a connection to the database
            conn3 = DriverManager.getConnection(url3);
            
            System.out.println("Connection2 to SQLite has been established.");
            
            Statement stmt3  = conn3.createStatement();
             String sql3;
           // String sql = "INSERT INTO warehouses VALUES(?,?,?)";
            //String sql = ("INSERT INTO warehouses(addend1,addend2,addend3) VALUES(?,?,?)",(em1,em2,em3));
            sql3 = "INSERT INTO DecryptionCostforUser(time) VALUES('"+NetTime1+"')";
            j = j+1;
           //String sql = ("INSERT INTO warehouses (addend1,addend2,addend3) VALUES (?, ?, ?, ?)",(em1,em2,em3));
          // String sql = "insert into" + warehouses + "em1,em2,em3";
           // String sql = "INSERT INTO stuffToPlot (unix, datestamp, keyword, value) VALUES (?, ?, ?, ?)";
            
             stmt3.executeQuery(sql3);
             System.out.println("Time inserted successfully");
                
//stmt1.update();
           // String t1 = "SELECT * FROM warehouses";
           // ResultSet rs1    = stmt1.executeQuery(sql);
            // ResultSet rs = stmt1.executeQuery(query);
            
            // loop through the result set
} catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn3 != null) {
                    conn3.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
 
 //DATABASE CONNECTION 3 END
 
 
 // END INSERTING TIME COMPUTATION for DECRYPTION AT USER SIDE
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
              
               
            }
            
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
 
 
 
 

}




}

