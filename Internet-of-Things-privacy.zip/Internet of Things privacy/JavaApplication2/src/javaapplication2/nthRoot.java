/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author CSPhD-26
 */
//public class nthRoot {
    
    /**

     ** Java Program to implement Nth Root Algorithm

     **/

     

    import java.util.Scanner;

     

    /** Class NthRoot **/

    public class nthRoot

    {

       
        
        
        
        public static double nthroot(int n, double x) {
  assert (n > 1 && x > 0);
  int np = n - 1;
  double g1 = x;
  double g2 = iter(g1, np, n, x);
  while (g1 != g2) {
    g1 = iter(g1, np, n, x);
    g2 = iter(iter(g2, np, n, x), np, n, x);
  }
  return g1;
}
 
private static double iter(double g, int np, int n, double x) {
  return (np * g + x / Math.pow(g, np)) / n;
}

        /** Main **/

        public static void main(String[] args)

        {

            Scanner scan = new Scanner(System.in);

            System.out.println("Nth Root Algorithm Test\n");

            System.out.println("Enter n and x");

            int n = scan.nextInt();

            double x = scan.nextInt();

            nthRoot nr = new nthRoot();

            double root = nthroot(n, x);

            System.out.println("\nRoot = "+ root);

        }    

    }