/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Random;

/**
 *
 * @author CSPhD-26
 */
public class intger {

    public intger(int i, int i0, Random random) {
    }
    
}
