
package javaapplication2;

/**
 *
 * @author CSPhD-26
 */
//public class RotateString {
    
import java.util.*;
import java.util.*;
public class RotateString {
     public static void main(String[] arg) 
   {
	
       String FinalRorate1 = rotate(2016, 1);
       System.out.println("Final value after rotation: " + FinalRorate1);
       
       int len =  FinalRorate1.length();
       
       
       int RT= Integer.parseInt(FinalRorate1);
       System.out.println("Final value after rotation: " + RT);
       int count = 0;

        while (RT != 0) {
            // num = num/10 number
            RT /= 10;
            ++count;
        }
        
        int diff = len-count;
        if(diff>0)
        {
        // insert flag into KMaaS
        
        }
        
        
        
}
     
     
  // START function to rotate number
    private static String rotate(int N, int P) {
        String inpstring = "";
        long num;
        long z = 0;

        long number = N;
        long number1 = number;

        number = N;
        num = P;

        long start = number;

        int numdigits = (int) Math.log10((double) number); // would return numdigits - 1

        int multiplier = (int) Math.pow(10.0, (double) numdigits);

        //System.out.println(numdigits);
        //System.out.println(multiplier);
        //while(true)
        for (int i = 0; i < num; i++) {

            long q = number / 10;

            long r = number % 10;

            //1234 = 123;
            number = number / 10;

            number = number + multiplier * r;

            //System.out.println(number);
            z = (int) number;

            if (number == start) {
                break;
            }

        }

        int count = 0;

        while (number1 != 0) {
            // num = num/10 number
            number1 /= 10;
            ++count;
        }

        //System.out.println("Number of digits: " + count);     
        int count1 = 0;

        while (number != 0) {
            // num = num/10 number
            number /= 10;
            ++count1;
        }

        //  System.out.println("Number of digits: " + count1);     
        int Netcount = count - count1;
        //System.out.println("Netcouont: " + Netcount);     
        int a = 0;
        int p = 0;
        long l1, l2;
        l1 = 0;
        l2 = z;

        String s1 = Long.toString(l1);    // converting long to String
        String s2 = Long.toString(z);

        for (int i = 0; i < Netcount; i++) {
            //number = Integer.valueOf(String.valueOf(p) + String.valueOf(number));
            //a = Integer.parseInt(Integer.toString(p) + Integer.toString((int) number));

            //System.out.println("Number of digits: " + l1);     
            //System.out.println("Number z: " + z);     
            s2 = s1 + s2;
            // long l3=Long.valueOf(s3).longValue();    // converting String to long
            //z=l3;
            //System.out.println(s3);

        }

        // System.out.println("Final value after rotation: " + s2);      
        // return s2;         
        return s2;

    }

// END function to rotate number   
     
     
     
     
     
}