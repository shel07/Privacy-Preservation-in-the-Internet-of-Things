




              int[] result = new int[3];
                 int sum = 0;
              Random random = new Random();
              int number =20;
              for (int i = 0; i < result.length; i++) {
            // here is the uneffecient part:
                 
                 int rand = random.nextInt(number);
                 if (sum + rand < number) {
                 result[i] = rand;
                sum += rand;
                } else {
                     i--;
                     }
                 }
               result[0] = number - sum;
              // System.out.println(result[0]);  
               
               for(int i=0;i<result.length;i++)
               {
                       
                   System.out.println("Temperatute");   
                   System.out.println(result[i]);  
               }
               
               






